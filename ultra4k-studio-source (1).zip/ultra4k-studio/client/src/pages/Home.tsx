import { useEffect, useMemo, useRef, useState } from "react";
import {
  Aperture,
  ArrowUpRight,
  Check,
  ChevronDown,
  CircleHelp,
  Copy,
  Download,
  Edit3,
  FileImage,
  Heart,
  History,
  Image as ImageIcon,
  LayoutGrid,
  Loader2,
  Menu,
  MoreHorizontal,
  PanelRight,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  Sparkles,
  Star,
  Trash2,
  Upload,
  WandSparkles,
  ZoomIn,
  ZoomOut,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

type WorkspaceView = "new" | "history" | "downloads" | "favorites" | "settings";
type AspectRatio = "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3" | "4:5" | "5:4" | "21:9";

type Generation = {
  id: string;
  prompt: string;
  aspectRatio: AspectRatio;
  imageSize: "4K";
  mimeType: string;
  imageUrl: string;
  previewUrl: string;
  downloadUrl: string;
  fileName: string;
  createdAt: number;
  downloadedAt?: number;
  isFavorite: boolean;
  source: "generated" | "edited";
};

const ASPECT_RATIOS: AspectRatio[] = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3", "4:5", "5:4", "21:9"];
const STORAGE_KEY = "ultra4k-generations-v1";

const sampleCards = [
  { label: "A quiet morning", ratio: "16:9", palette: "sample-morning" },
  { label: "Editorial still life", ratio: "4:5", palette: "sample-editorial" },
  { label: "Neon architecture", ratio: "3:2", palette: "sample-neon" },
];

function formatDate(timestamp: number) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(timestamp);
}

function ratioClass(ratio: string) {
  return ratio.replace(":", "x");
}

function safeParseHistory(): Generation[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function Home() {
  const [activeView, setActiveView] = useState<WorkspaceView>("new");
  const [prompt, setPrompt] = useState("");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("16:9");
  const [outputFormat, setOutputFormat] = useState<"image/jpeg" | "image/png">("image/jpeg");
  const [stockReady, setStockReady] = useState(false);
  const [history, setHistory] = useState<Generation[]>(safeParseHistory);
  const [result, setResult] = useState<Generation | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [error, setError] = useState("");
  const [editFile, setEditFile] = useState<{ data: string; mimeType: string; name: string } | null>(null);
  const [mobileInspectorOpen, setMobileInspectorOpen] = useState(false);
  const [viewerItem, setViewerItem] = useState<Generation | null>(null);
  const [viewerZoom, setViewerZoom] = useState(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(0, 30)));
  }, [history]);

  useEffect(() => {
    if (!isGenerating) return;
    const timer = window.setInterval(() => setProgressStep((value) => (value + 1) % 4), 1600);
    return () => window.clearInterval(timer);
  }, [isGenerating]);

  const visibleHistory = useMemo(() => {
    if (activeView === "favorites") return history.filter((item) => item.isFavorite);
    if (activeView === "downloads") return history.filter((item) => item.downloadedAt);
    return history;
  }, [activeView, history]);

  const toggleFavorite = (id: string) => {
    setHistory((items) => items.map((item) => (item.id === id ? { ...item, isFavorite: !item.isFavorite } : item)));
    setResult((item) => (item?.id === id ? { ...item, isFavorite: !item.isFavorite } : item));
  };

  const deleteGeneration = (id: string) => {
    setHistory((items) => items.filter((item) => item.id !== id));
    setResult((item) => (item?.id === id ? null : item));
    toast.success("Removed from your library");
  };

  const markDownloaded = (id: string) => {
    const downloadedAt = Date.now();
    setHistory((items) => items.map((item) => (item.id === id ? { ...item, downloadedAt } : item)));
    setResult((item) => (item?.id === id ? { ...item, downloadedAt } : item));
  };

  const openViewer = (item: Generation) => {
    setViewerItem(item);
    setViewerZoom(1);
  };

  const closeViewer = () => {
    setViewerItem(null);
    setViewerZoom(1);
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeViewer();
      if (event.key === "+" || event.key === "=") setViewerZoom((value) => Math.min(3, Number((value + 0.25).toFixed(2))));
      if (event.key === "-") setViewerZoom((value) => Math.max(0.5, Number((value - 0.25).toFixed(2))));
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const handleImageUpload = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please choose an image file");
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      toast.error("Please choose an image smaller than 15 MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setEditFile({ data: String(reader.result).split(",")[1] ?? "", mimeType: file.type, name: file.name });
      setActiveView("new");
      setError("");
      toast.success("Image ready to edit");
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    const cleanPrompt = prompt.trim();
    if (cleanPrompt.length < 4) {
      setError("Add a little more detail so the model has something to work with.");
      return;
    }

    setIsGenerating(true);
    setError("");
    setProgressStep(0);

    try {
      const endpoint = editFile ? "/api/edit" : "/api/generate";
      const body = editFile
        ? { prompt: cleanPrompt, aspectRatio, imageSize: "4K", outputFormat, stockReady, imageBase64: editFile.data, mimeType: editFile.mimeType }
        : { prompt: cleanPrompt, aspectRatio, imageSize: "4K", outputFormat, stockReady };

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const payload = (await response.json().catch(() => ({}))) as { message?: string; error?: string; [key: string]: unknown };
      if (!response.ok) throw new Error(payload.message || payload.error || "Generation failed. Please try again.");

      const generation: Generation = {
        id: String(payload.id ?? crypto.randomUUID()),
        prompt: cleanPrompt,
        aspectRatio,
        imageSize: "4K",
        mimeType: String(payload.mimeType ?? "image/jpeg"),
        imageUrl: String(payload.imageUrl ?? payload.dataUrl ?? ""),
        previewUrl: String(payload.previewUrl ?? payload.imageUrl ?? payload.dataUrl ?? ""),
        downloadUrl: String(payload.downloadUrl ?? payload.imageUrl ?? payload.dataUrl ?? ""),
        fileName: String(payload.fileName ?? `ultra4k-${new Date().toISOString().slice(0, 10)}.jpg`),
        createdAt: Date.now(),
        isFavorite: false,
        source: editFile ? "edited" : "generated",
      };

      if (!generation.imageUrl) throw new Error("The API returned no image. 4K generation failed — no lower-resolution fallback was used.");
      setResult(generation);
      setHistory((items) => [generation, ...items.filter((item) => item.id !== generation.id)].slice(0, 30));
      setEditFile(null);
      toast.success(editFile ? "Edit ready" : "Image saved to Gallery", { description: "Your original file is ready. Download it whenever you want." });
    } catch (generationError) {
      setError(generationError instanceof Error ? generationError.message : "Generation failed. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyPrompt = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success("Prompt copied");
    } catch {
      toast.error("Could not copy the prompt");
    }
  };

  const resetWorkspace = () => {
    setPrompt("");
    setResult(null);
    setError("");
    setEditFile(null);
    setActiveView("new");
  };

  const navItems: { id: WorkspaceView; label: string; icon: typeof Sparkles }[] = [
    { id: "new", label: "New generation", icon: Sparkles },
    { id: "history", label: "Gallery", icon: LayoutGrid },
    { id: "downloads", label: "Downloads", icon: Download },
    { id: "favorites", label: "Favorites", icon: Star },
  ];

  return (
    <div className="studio-shell">
      <aside className="studio-sidebar">
        <div className="brand-lockup" onClick={resetWorkspace} role="button" tabIndex={0}>
          <span className="brand-mark"><Aperture size={17} strokeWidth={2.3} /></span>
          <span>Ultra<span>4K</span> Studio</span>
        </div>

        <button className="new-generation-btn" onClick={resetWorkspace}>
          <Plus size={16} />
          <span>New generation</span>
          <span className="shortcut">⌘ K</span>
        </button>

        <div className="sidebar-section-label">Workspace</div>
        <nav className="sidebar-nav" aria-label="Workspace navigation">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`sidebar-link ${activeView === id ? "active" : ""}`} onClick={() => setActiveView(id)}>
              <Icon size={17} strokeWidth={activeView === id ? 2.2 : 1.7} />
              <span>{label}</span>
              {id === "history" && history.length > 0 ? <span className="nav-count">{history.length}</span> : null}
              {id === "downloads" && history.filter((item) => item.downloadedAt).length > 0 ? <span className="nav-count">{history.filter((item) => item.downloadedAt).length}</span> : null}
            </button>
          ))}
          <button className={`sidebar-link ${activeView === "settings" ? "active" : ""}`} onClick={() => setActiveView("settings")}>
            <Settings2 size={17} strokeWidth={1.7} />
            <span>Settings</span>
          </button>
        </nav>

        <div className="sidebar-bottom">
          <div className="quality-badge">
            <span className="pulse-dot" />
            <div>
              <strong>Original output active</strong>
              <span>Direct downloads, always</span>
            </div>
            <ArrowUpRight size={14} />
          </div>
          <button className="sidebar-help"><CircleHelp size={16} /> Help center <span>↗</span></button>
          <div className="profile-row">
            <div className="avatar">AS</div>
            <div><strong>Alex Smith</strong><span>Personal workspace</span></div>
            <MoreHorizontal size={17} className="muted-icon" />
          </div>
        </div>
      </aside>

      <main className="studio-main">
        <header className="studio-topbar">
          <div className="mobile-brand"><span className="brand-mark"><Aperture size={16} /></span><span>Ultra<span>4K</span></span></div>
          <div className="breadcrumb"><span>Studio</span><span className="breadcrumb-slash">/</span><strong>{activeView === "new" ? "Create an image" : activeView[0].toUpperCase() + activeView.slice(1)}</strong></div>
          <div className="topbar-actions">
            <button className="icon-button search-button" aria-label="Search"><Search size={17} /></button>
            <button className="icon-button" aria-label="Toggle inspector" onClick={() => setMobileInspectorOpen((value) => !value)}><PanelRight size={17} /></button>
            <div className="topbar-avatar">AS</div>
          </div>
        </header>

        {activeView === "settings" ? (
          <section className="content-section settings-view">
            <div className="section-heading"><div><span className="eyebrow">Workspace preferences</span><h1>Settings</h1><p>Keep your creative defaults close and your API connection safe.</p></div></div>
            <div className="settings-grid">
              <div className="settings-card"><div className="settings-icon violet"><Zap size={18} /></div><div><strong>4K export</strong><p>Every download is rendered as a high-quality 3840px export with no browser canvas compression.</p></div><span className="settings-status">On</span></div>
              <div className="settings-card"><div className="settings-icon lime"><ImageIcon size={18} /></div><div><strong>Enhanced 4K downloads</strong><p>Downloads use a server-side detail export, never a browser resize or canvas screenshot.</p></div><span className="settings-status">On</span></div>
              <div className="settings-card"><div className="settings-icon blue"><History size={18} /></div><div><strong>Local history</strong><p>Recent metadata is kept in this browser so you can pick up where you left off.</p></div><button className="text-button" onClick={() => { setHistory([]); localStorage.removeItem(STORAGE_KEY); toast.success("History cleared"); }}>Clear</button></div>
            </div>
            <div className="settings-note"><CircleHelp size={17} /><span>Ultra4K Image Engine is connected server-side. Generated files are delivered without browser resizing.</span></div>
          </section>
        ) : activeView === "history" || activeView === "downloads" || activeView === "favorites" ? (
          <section className="content-section library-view">
            <div className="section-heading"><div><span className="eyebrow">Dark media library</span><h1>{activeView === "favorites" ? "Favorites" : activeView === "downloads" ? "Downloads" : "Gallery"}</h1><p>{activeView === "favorites" ? "The images you want to keep close." : activeView === "downloads" ? "Files you have downloaded from your gallery." : "Every generated image is saved here automatically."}</p></div><button className="soft-button" onClick={resetWorkspace}><Plus size={16} /> New generation</button></div>
            {visibleHistory.length === 0 ? <div className="empty-library"><div className="empty-icon"><LayoutGrid size={22} /></div><h3>{activeView === "favorites" ? "No favorites yet" : activeView === "downloads" ? "No downloads yet" : "Your gallery is waiting"}</h3><p>{activeView === "downloads" ? "Use Download on any gallery image and it will appear here." : "Generate an image and it will appear here automatically."}</p><button className="primary-button compact" onClick={resetWorkspace}><Sparkles size={15} /> Create an image</button></div> : <div className="library-grid">{visibleHistory.map((item) => <LibraryCard key={item.id} item={item} onFavorite={() => toggleFavorite(item.id)} onDelete={() => deleteGeneration(item.id)} onCopy={() => handleCopyPrompt(item.prompt)} onDownloaded={() => markDownloaded(item.id)} onSelect={() => { setResult(item); setPrompt(item.prompt); setAspectRatio(item.aspectRatio); setActiveView("new"); openViewer(item); }} />)}</div>}
          </section>
        ) : (
          <div className="workspace-content">
            <section className="creation-column">
              <div className="intro-row">
                <div><span className="eyebrow">AI image workspace</span><h1>Create an image</h1><p>Turn a thought into a high-resolution visual.</p></div>
                <div className="live-chip"><span className="pulse-dot" /> Live</div>
              </div>

              <div className="prompt-card">
                <div className="prompt-card-top"><span className="prompt-label"><WandSparkles size={15} /> Prompt</span><span className="prompt-capacity">{prompt.length}/2,000</span></div>
                {editFile ? <div className="edit-file-pill"><FileImage size={15} /><span>Editing <strong>{editFile.name}</strong></span><button onClick={() => setEditFile(null)} aria-label="Remove edit image"><X size={14} /></button></div> : null}
                <textarea value={prompt} onChange={(event) => { setPrompt(event.target.value); setError(""); }} placeholder={editFile ? "Describe the changes you want to make..." : "Describe the image you want to create..."} maxLength={2000} rows={5} />
                <div className="prompt-card-bottom"><div className="prompt-hints"><span>Try</span><button onClick={() => setPrompt("A cinematic glass house above the clouds at blue hour")}>cinematic</button><button onClick={() => setPrompt("Editorial still life of ripe figs and brushed steel")}>editorial</button><button onClick={() => setPrompt("A quiet coastal landscape with sculptural rock formations")}>landscape</button></div><button className="prompt-expand" aria-label="Expand prompt"><MoreHorizontal size={18} /></button></div>
              </div>

              {error ? <div className="error-banner"><X size={16} /><span>{error}</span></div> : null}

              <div className="generation-actions">
                <div className="generation-left-actions"><div className="quick-ratios" aria-label="Aspect ratio presets"><span>Ratio</span>{(["16:9", "9:16", "1:1", "4:5"] as AspectRatio[]).map((ratio) => <button key={ratio} className={aspectRatio === ratio ? "selected" : ""} onClick={() => setAspectRatio(ratio)} aria-pressed={aspectRatio === ratio}>{ratio}</button>)}</div><button className="subtle-edit-button" onClick={() => fileInputRef.current?.click()}><Upload size={15} /><span>{editFile ? "Replace source image" : "Edit an image"}</span></button></div>
                <input ref={fileInputRef} type="file" accept="image/*" hidden onChange={(event) => handleImageUpload(event.target.files?.[0])} />
                <button className="generate-button" disabled={isGenerating} onClick={handleGenerate}>{isGenerating ? <><Loader2 size={17} className="spin" /> Generating your image...</> : <><Sparkles size={17} /> {editFile ? "Generate edit" : "Generate image"}<span className="generate-arrow">↗</span></>}</button>
              </div>

              <div className="canvas-header"><div><span className="eyebrow">Output canvas</span><h2>{result ? "Your generated image" : "A clear canvas for your next idea"}</h2></div>{result ? <span className="output-meta"><span className="status-dot" /> {result.aspectRatio} · 4K JPEG</span> : <span className="output-meta muted">Waiting for a prompt</span>}</div>
              <div className={`output-canvas ratio-${ratioClass(result?.aspectRatio ?? aspectRatio)} ${result ? "has-result" : ""}`}>
                {result ? <><button className="preview-image-button" onClick={() => openViewer(result)} aria-label="Open image viewer"><img src={result.previewUrl || result.imageUrl} alt={result.prompt} /></button><div className="canvas-overlay"><span>{result.source === "edited" ? "Edited image" : "Generated image"}</span><span>Click to zoom</span></div></> : <div className="canvas-empty"><div className="canvas-orbit"><div className="orbit-core"><Sparkles size={24} /></div></div><span className="canvas-empty-title">Your high-res preview will appear here</span><span className="canvas-empty-subtitle">Start with a prompt or upload an image to edit.</span><div className="canvas-specs"><span><Check size={13} /> 4K preview</span><span><Check size={13} /> Detail export</span><span><Check size={13} /> Direct download</span></div></div>}
              </div>

              {result ? <div className="result-toolbar"><a className="download-button" href={result.downloadUrl || result.imageUrl} download={result.fileName} onClick={() => markDownloaded(result.id)}><Download size={16} /> Download original</a><button className="toolbar-button" onClick={() => { setPrompt(result.prompt); setEditFile(null); handleGenerate(); }}><RotateCcw size={15} /> Regenerate</button><button className="toolbar-button" onClick={() => fileInputRef.current?.click()}><Edit3 size={15} /> Edit</button><button className={`toolbar-button ${result.isFavorite ? "favorite-active" : ""}`} onClick={() => toggleFavorite(result.id)}><Heart size={15} fill={result.isFavorite ? "currentColor" : "none"} /> {result.isFavorite ? "Favorited" : "Favorite"}</button><button className="toolbar-icon-button" onClick={() => handleCopyPrompt(result.prompt)} aria-label="Copy prompt"><Copy size={15} /></button><button className="toolbar-icon-button danger" onClick={() => deleteGeneration(result.id)} aria-label="Delete image"><Trash2 size={15} /></button></div> : null}

              <div className="recent-header"><span className="eyebrow">Recent generations</span><button className="link-button" onClick={() => setActiveView("history")}>View all <ArrowUpRight size={14} /></button></div>
              <div className="recent-grid">{history.slice(0, 3).map((item) => <RecentCard key={item.id} item={item} onClick={() => { setResult(item); setPrompt(item.prompt); setAspectRatio(item.aspectRatio); openViewer(item); }} />)}{history.length === 0 ? sampleCards.map((item) => <div className="sample-card" key={item.label}><div className={`sample-art ${item.palette}`}><span className="sample-badge">Sample</span></div><div className="sample-copy"><strong>{item.label}</strong><span>{item.ratio} · inspiration</span></div></div>) : null}</div>
            </section>

            <aside className={`inspector-panel ${mobileInspectorOpen ? "mobile-open" : ""}`}>
              <div className="inspector-heading"><div><span className="eyebrow">Generation setup</span><h2>Controls</h2></div><button className="inspector-close" onClick={() => setMobileInspectorOpen(false)} aria-label="Close controls"><X size={17} /></button></div>
              <div className="inspector-group"><label className="control-label">Image engine <span className="control-info">i</span></label><div className="select-control"><div className="model-orb"><Sparkles size={14} /></div><select defaultValue="ultra4k-engine"><option value="ultra4k-engine">Ultra4K Image Engine</option></select><ChevronDown size={15} /></div><span className="control-caption">Fast, high-resolution output with direct original downloads</span></div>
              <div className="inspector-divider" />
              <div className="inspector-group"><label className="control-label">Aspect ratio <span className="control-info">i</span></label><div className="ratio-grid">{ASPECT_RATIOS.map((ratio) => <button key={ratio} className={`ratio-option ${aspectRatio === ratio ? "selected" : ""}`} onClick={() => setAspectRatio(ratio)}><span className={`ratio-preview ratio-preview-${ratioClass(ratio)}`} /><span>{ratio}</span>{aspectRatio === ratio ? <Check size={13} /> : null}</button>)}</div></div>
              <div className="inspector-divider" />
              <div className="inspector-group"><label className="control-label">Resolution</label><div className="locked-control selected"><div><strong>4K detail export</strong><span>3840px server render</span></div><span className="selected-check"><Check size={13} /></span></div><span className="control-caption">Gallery preview and download use the enhanced 4K detail file with high-quality color and sharpening.</span></div>
              <div className="inspector-group"><label className="control-label">Output format</label><div className="select-control compact-select"><div className="format-icon">{outputFormat === "image/png" ? "PNG" : "JPG"}</div><select value={outputFormat} onChange={(event) => setOutputFormat(event.target.value as "image/jpeg" | "image/png")}><option value="image/jpeg">JPEG</option><option value="image/png">PNG (when supported)</option></select><ChevronDown size={15} /></div></div>
              <div className="inspector-divider" />
              <div className="stock-toggle-row"><div className="stock-toggle-copy"><div className="stock-icon"><Star size={15} /></div><div><strong>Adobe Stock Ready</strong><span>Commercial-safe prompt tuning</span></div></div><button className={`toggle ${stockReady ? "on" : ""}`} onClick={() => setStockReady((value) => !value)} aria-label="Toggle Adobe Stock Ready"><span /></button></div>
              <div className="inspector-footer"><div className="quality-line"><span className="quality-ring"><Check size={12} /></span><span><strong>Quality guardrails on</strong><small>Natural detail · accurate geometry · clean edges</small></span></div><button className="inspector-more"><Settings2 size={14} /> Advanced <ChevronDown size={14} /></button></div>
            </aside>
          </div>
        )}
      </main>

      {viewerItem ? <div className="image-viewer" role="dialog" aria-modal="true" aria-label="Image viewer" onClick={closeViewer}><div className="viewer-topbar"><div><strong>Ultra4K Gallery</strong><span>{viewerItem.aspectRatio} · enhanced 4K detail preview</span></div><button className="viewer-close" onClick={closeViewer} aria-label="Close viewer"><X size={20} /></button></div><div className="viewer-stage" onClick={(event) => event.stopPropagation()}><img src={viewerItem.previewUrl || viewerItem.imageUrl} alt={viewerItem.prompt} style={{ transform: `scale(${viewerZoom})` }} /></div><div className="viewer-toolbar" onClick={(event) => event.stopPropagation()}><button onClick={() => setViewerZoom((value) => Math.max(0.5, Number((value - 0.25).toFixed(2))))} aria-label="Zoom out"><ZoomOut size={18} /></button><span>{Math.round(viewerZoom * 100)}%</span><button onClick={() => setViewerZoom((value) => Math.min(3, Number((value + 0.25).toFixed(2))))} aria-label="Zoom in"><ZoomIn size={18} /></button><a className="viewer-download" href={viewerItem.downloadUrl || viewerItem.imageUrl} download={viewerItem.fileName} onClick={() => markDownloaded(viewerItem.id)}><Download size={16} /> Download 4K</a><button onClick={() => toggleFavorite(viewerItem.id)} className={viewerItem.isFavorite ? "favorite-active" : ""}><Heart size={16} fill={viewerItem.isFavorite ? "currentColor" : "none"} /> {viewerItem.isFavorite ? "Saved" : "Favorite"}</button></div><p className="viewer-caption">{viewerItem.prompt}</p></div> : null}

      <nav className="mobile-nav" aria-label="Mobile navigation"><button onClick={resetWorkspace} className={activeView === "new" ? "active" : ""}><Sparkles size={18} /><span>Create</span></button><button onClick={() => setActiveView("history")} className={activeView === "history" ? "active" : ""}><LayoutGrid size={18} /><span>Gallery</span></button><button onClick={() => setActiveView("downloads")} className={activeView === "downloads" ? "active" : ""}><Download size={18} /><span>Downloads</span></button><button onClick={() => setMobileInspectorOpen(true)}><PanelRight size={18} /><span>Controls</span></button></nav>
    </div>
  );
}

function LibraryCard({ item, onFavorite, onDelete, onCopy, onDownloaded, onSelect }: { item: Generation; onFavorite: () => void; onDelete: () => void; onCopy: () => void; onDownloaded: () => void; onSelect: () => void }) {
  return <article className="library-card"><button className="library-image" onClick={onSelect}><img src={item.previewUrl || item.imageUrl} alt={item.prompt} /><span className="library-size">{item.downloadedAt ? "Downloaded" : "4K detail"}</span></button><div className="library-card-body"><div><span className="library-date">{formatDate(item.createdAt)} · {item.aspectRatio}</span><h3>{item.prompt}</h3></div><div className="library-actions"><button onClick={onFavorite} className={item.isFavorite ? "favorite-active" : ""} aria-label="Favorite"><Heart size={15} fill={item.isFavorite ? "currentColor" : "none"} /></button><button onClick={onCopy} aria-label="Copy prompt"><Copy size={15} /></button><a href={item.downloadUrl || item.imageUrl} download={item.fileName} onClick={onDownloaded} aria-label="Download 4K"><Download size={15} /></a><button onClick={onDelete} className="danger" aria-label="Delete"><Trash2 size={15} /></button></div></div></article>;
}

function RecentCard({ item, onClick }: { item: Generation; onClick: () => void }) {
  return <button className="recent-card" onClick={onClick}><div className={`recent-image ratio-${ratioClass(item.aspectRatio)}`}><img src={item.previewUrl || item.imageUrl} alt="" /><span>{item.aspectRatio}</span></div><div className="recent-copy"><strong>{item.prompt}</strong><span>{formatDate(item.createdAt)} · 4K detail</span></div></button>;
}
