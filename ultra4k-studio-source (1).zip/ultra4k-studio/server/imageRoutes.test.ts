import { describe, expect, it } from "vitest";
import { registerImageRoutes } from "./imageRoutes";

describe("Ultra4K image routes", () => {
  it("registers dedicated generate and edit endpoints", () => {
    const paths: string[] = [];
    registerImageRoutes({ post: (path: string) => paths.push(`POST ${path}`), get: (path: string) => paths.push(`GET ${path}`) } as any);
    expect(paths).toEqual(["POST /api/generate", "POST /api/edit", "GET /api/download"]);
  });

  it("rejects an empty prompt before calling the image provider", async () => {
    const routes: Array<{ path: string; handler: (req: any, res: any) => Promise<void> }> = [];
    registerImageRoutes({ post: (path: string, handler: any) => routes.push({ path, handler }), get: () => undefined } as any);
    const response = { statusCode: 200, body: null as any };
    const res = {
      status(code: number) { response.statusCode = code; return this; },
      json(body: any) { response.body = body; return this; },
    };

    await routes.find((route) => route.path === "/api/generate")?.handler({ body: { prompt: "x", aspectRatio: "16:9" } }, res);
    expect(response.statusCode).toBe(400);
    expect(response.body.message).toContain("between 4 and 2,000 characters");
  });
});
