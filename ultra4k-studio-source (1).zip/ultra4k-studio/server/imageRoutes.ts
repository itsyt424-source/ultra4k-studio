import type { Express, Request, Response } from "express";
import { randomUUID } from "node:crypto";
import { generateImage } from "./_core/imageGeneration";
import { storageGetSignedUrl } from "./storage";
import sharp from "sharp";

const ASPECT_RATIOS = new Set(["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3", "4:5", "5:4", "21:9"]);
const MAX_EDIT_BYTES = 15 * 1024 * 1024;

type ImageRequest = {
  prompt?: unknown;
  aspectRatio?: unknown;
  imageSize?: unknown;
  outputFormat?: unknown;
  stockReady?: unknown;
  imageBase64?: unknown;
  mimeType?: unknown;
};

function enhancePrompt(prompt: string, aspectRatio: string, stockReady: boolean) {
  const lower = prompt.toLowerCase();
  const category = lower.includes("product") || lower.includes("packaging")
    ? "commercial product photography with accurate materials and geometry"
    : lower.includes("architecture") || lower.includes("building") || lower.includes("interior")
      ? "architectural photography with natural perspective and accurate proportions"
      : lower.includes("food") || lower.includes("dish")
        ? "editorial food photography with appetizing natural textures"
        : lower.includes("illustration") || lower.includes("poster")
          ? "intentional illustration craft with clean edges and coherent forms"
          : "professional high-resolution photography with realistic materials";
  const stock = stockReady ? " Commercial stock composition, useful copy space where appropriate, no brand logos, trademarks, copyrighted characters, unnecessary text, or watermark." : "";
  return `${prompt.trim()}\n\n${category}. Dark, cinematic tonal range only when it suits the subject; realistic lighting, natural shadows, accurate geometry, clean edges, fine detail, photographic depth, realistic reflections, and natural texture. Compose for ${aspectRatio}. Avoid blur, noise, banding, compression artifacts, malformed objects, duplicated objects, broken perspective, fake logos, and oversharpening.${stock}`;
}

function validatePayload(body: ImageRequest) {
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const aspectRatio = typeof body.aspectRatio === "string" ? body.aspectRatio : "16:9";
  if (prompt.length < 4 || prompt.length > 2000) throw new Error("Please enter a prompt between 4 and 2,000 characters.");
  if (!ASPECT_RATIOS.has(aspectRatio)) throw new Error("That aspect ratio is not supported.");
  return { prompt, aspectRatio, stockReady: body.stockReady === true };
}

function exportDimensions(aspectRatio: string) {
  if (aspectRatio === "1:1") return { width: 3840, height: 3840 };
  if (aspectRatio === "9:16") return { width: 2160, height: 3840 };
  return { width: 3840, height: 2160 };
}

function getImageErrorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);
  if (/quota|rate limit|resource exhausted/i.test(message)) return "Image generation quota reached. Please try again later.";
  if (/storage/i.test(message)) return "The image was generated, but direct download storage is temporarily unavailable.";
  return "Image generation failed. Please try again.";
}

async function handleGeneration(req: Request, res: Response, mode: "generate" | "edit") {
  try {
    const body = req.body as ImageRequest;
    const { prompt, aspectRatio, stockReady } = validatePayload(body);
    const imageBase64 = typeof body.imageBase64 === "string" ? body.imageBase64 : "";
    const mimeType = typeof body.mimeType === "string" ? body.mimeType : "image/jpeg";

    if (mode === "edit") {
      if (!imageBase64 || imageBase64.length > Math.ceil(MAX_EDIT_BYTES * 1.4)) return res.status(400).json({ message: "Please upload an image smaller than 15 MB." });
      if (!mimeType.startsWith("image/")) return res.status(400).json({ message: "The edit source must be an image." });
    }

    const result = await generateImage({
      prompt: enhancePrompt(mode === "edit" ? `${prompt}. Edit the provided image while preserving everything not requested.` : prompt, aspectRatio, stockReady),
      model: "MODEL_GPT_IMAGE_2",
      quality: "medium",
      ...(mode === "edit" ? { originalImages: [{ b64Json: imageBase64, mimeType }] } : {}),
    });

    if (!result.url) return res.status(502).json({ message: "Image generation returned no downloadable file." });
    const fileName = `ultra4k-${new Date().toISOString().slice(0, 10)}-${randomUUID().slice(0, 6)}.png`;
    const storageKey = result.url.startsWith("/manus-storage/") ? result.url.slice("/manus-storage/".length) : "";
    const requestedFormat = body.outputFormat === "image/png" ? "png" : "jpeg";
    const exportName = fileName.replace(/\.png$/, requestedFormat === "png" ? ".png" : ".jpg");
    const exportPath = storageKey ? `/api/download?key=${encodeURIComponent(storageKey)}&filename=${encodeURIComponent(exportName)}&quality=4k&format=${requestedFormat}&aspectRatio=${encodeURIComponent(aspectRatio)}` : result.url;
    return res.json({
      id: randomUUID(),
      imageUrl: result.url,
      fileName,
      mimeType: "image/png",
      aspectRatio,
      resolution: "original-high-resolution",
      originalFile: true,
      model: "platform-image-service",
      note: "Download uses the original provider file; no browser upscaling or recompression is used.",
      downloadUrl: exportPath,
      previewUrl: storageKey ? `${exportPath}&inline=1` : result.url,
    });
  } catch (error) {
    console.error(`[Ultra4K] ${mode} request failed:`, error);
    const validationMessage = error instanceof Error ? error.message : "";
    if (/between 4 and 2,000|aspect ratio is not supported/i.test(validationMessage)) {
      return res.status(400).json({ message: validationMessage });
    }
    return res.status(500).json({ message: getImageErrorMessage(error) });
  }
}

async function handleDownload(req: Request, res: Response) {
  try {
    const key = typeof req.query.key === "string" ? req.query.key : "";
    const requestedName = typeof req.query.filename === "string" ? req.query.filename : "ultra4k-original.png";
    const is4K = req.query.quality === "4k";
    const format = req.query.format === "png" ? "png" : "jpeg";
    const isInline = req.query.inline === "1";
    const aspectRatio = typeof req.query.aspectRatio === "string" ? req.query.aspectRatio : "16:9";
    if (!key || key.includes("..") || key.startsWith("/")) return res.status(400).json({ message: "Invalid download request." });
    const signedUrl = await storageGetSignedUrl(key);
    const upstream = await fetch(signedUrl);
    if (!upstream.ok) return res.status(502).json({ message: "The original file is temporarily unavailable." });
    const sourceBuffer = Buffer.from(await upstream.arrayBuffer());
    const dimensions = exportDimensions(aspectRatio);
    const outputBuffer = is4K
      ? await sharp(sourceBuffer).resize({ ...dimensions, fit: "cover", position: "centre", withoutEnlargement: false, kernel: sharp.kernel.lanczos3, fastShrinkOnLoad: false }).sharpen({ sigma: 0.75, m1: 1, m2: 0.25, x1: 2, y2: 10, y3: 20 }).toFormat(format, format === "jpeg" ? { quality: 100, chromaSubsampling: "4:4:4", progressive: true, trellisQuantisation: true, overshootDeringing: true } : { compressionLevel: 6, palette: false }).toBuffer()
      : sourceBuffer;
    const safeName = requestedName.replace(/\.(png|jpe?g)$/i, format === "png" ? ".png" : ".jpg").replace(/[^a-zA-Z0-9._-]/g, "_");
    res.setHeader("Content-Type", format === "png" ? "image/png" : "image/jpeg");
    res.setHeader("Content-Disposition", `${isInline ? "inline" : "attachment"}; filename="${safeName}"`);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Image-Export", is4K ? "3840px-high-quality-export" : "original");
    return res.send(outputBuffer);
  } catch (error) {
    console.error("[Ultra4K] download failed:", error);
    return res.status(500).json({ message: "Direct download failed. Please try again." });
  }
}

export function registerImageRoutes(app: Express) {
  app.post("/api/generate", (req, res) => void handleGeneration(req, res, "generate"));
  app.post("/api/edit", (req, res) => void handleGeneration(req, res, "edit"));
  app.get("/api/download", (req, res) => void handleDownload(req, res));
}
