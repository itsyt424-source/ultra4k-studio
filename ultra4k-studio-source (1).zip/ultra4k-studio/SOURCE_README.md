# Ultra4K Studio — Source Code

## Included

- React + Vite frontend in `client/`
- Dark gallery, downloads, favorites, full-screen zoom viewer, and aspect-ratio controls
- Express backend in `server/`
- Server-side 4K export and direct download route
- Drizzle schema and database configuration
- `package.json`, lockfile, TypeScript, Vite, and Tailwind configuration

## Run locally

```bash
pnpm install
pnpm dev
```

The app expects the platform environment variables used by the Manus full-stack template, including the built-in image service and storage configuration.

## Validate

```bash
pnpm test --run
pnpm check
pnpm build
```

## Important files

- `client/index.html` — document entry HTML
- `client/src/index.css` — full dark visual system and responsive styles
- `client/src/pages/Home.tsx` — main application UI and interactions
- `server/imageRoutes.ts` — generation, 4K export, preview, and download routes
- `server/_core/imageGeneration.ts` — server-side image generation helper
- `drizzle/schema.ts` — database schema
